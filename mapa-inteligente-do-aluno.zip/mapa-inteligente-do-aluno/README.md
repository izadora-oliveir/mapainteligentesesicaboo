# Mapa Inteligente do Aluno — SESI

Acompanhamento pedagógico orientado por dados, com login institucional
(Microsoft Entra ID) e dados de alunos lidos em tempo real do SharePoint
via Microsoft Graph. **Nenhum dado de aluno existe no código-fonte.**

> ⚠️ Este projeto ainda **não está com o login funcionando**: ele só
> funciona depois que o TI fizer as três configurações abaixo (App
> Registration, listas no SharePoint e variáveis de ambiente no
> Netlify). Sem isso, a tela de login aparece mas a autenticação falha.

## 1. Estrutura do projeto

```
mapa-inteligente-do-aluno/
├── index.html              # app principal (login + dashboards)
├── privacidade.html         # política de privacidade (LGPD)
├── build-config.js          # gera src/config.js a partir das env vars no deploy
├── netlify.toml              # build, headers de segurança (CSP, HSTS...)
├── .env.example
├── src/
│   ├── app.js               # orquestração (gate de login, navegação)
│   ├── auth.js               # MSAL.js — login Microsoft, token só em memória
│   ├── sharepoint.js         # leitura/gravação via Microsoft Graph
│   ├── dashboard.js          # cálculos pedagógicos e gráficos
│   ├── styles.css
│   └── config.js             # placeholder local; sobrescrito no build
└── assets/
    └── logo-sesi.png         # (adicionar a logo aqui)
```

## 2. Passo a passo para o TI — App Registration no Entra ID

1. Acessar [entra.microsoft.com](https://entra.microsoft.com) com uma conta
   de administrador do tenant.
2. **Identity > Applications > App registrations > New registration**.
3. Nome: `Mapa Inteligente do Aluno`.
4. **Supported account types**: apenas contas deste diretório organizacional
   (single tenant) — é isso que garante que só contas autorizadas acessam.
5. **Redirect URI**: tipo `Single-page application (SPA)`, valor:
   `https://mapainteligentesesicabo.netlify.app`
   (e também `http://localhost:5500` se for testar localmente).
6. Depois de criado, anotar:
   - **Application (client) ID** → vai em `VITE_ENTRA_CLIENT_ID`
   - **Directory (tenant) ID** → vai em `VITE_ENTRA_TENANT_ID`
7. Em **API permissions**, adicionar (Microsoft Graph, *Delegated*):
   - `User.Read`
   - `Sites.Read.All` (ou `Sites.Selected`, mais restritivo, se preferirem
     liberar acesso só ao site específico do SharePoint — recomendado).
8. Clicar em **Grant admin consent** para o tenant.
9. **Não é necessário criar client secret** — é um SPA público (MSAL com
   PKCE), não usa secret.

## 3. Passo a passo — Listas no SharePoint

Criar um site/biblioteca no SharePoint institucional com duas listas:

**Lista `Alunos`**

| Coluna | Tipo |
|---|---|
| Nome | Texto |
| Serie | Texto |
| Turma | Texto |
| Matricula | Texto |
| Status | Escolha (Ativo/Inativo) |

**Lista `RegistrosPedagogicos`**

| Coluna | Tipo |
|---|---|
| AlunoID | Lookup (para a lista Alunos) |
| Disciplina | Texto |
| Nota | Número |
| Frequencia | Número |
| Habilidade | Texto |
| Bimestre | Texto |
| DataRegistro | Data |
| Observacao | Texto |

O app grava automaticamente `ProfessorNome`, `ProfessorEmail` e
`RegistradoEm` a cada novo registro pedagógico — vale criar essas três
colunas extras na lista `RegistrosPedagogicos` (Texto, Texto, Data/Hora).

Para obter o **Site ID** (`VITE_SHAREPOINT_SITE_ID`), com um token de
administrador, acessar no navegador:

```
https://graph.microsoft.com/v1.0/sites/SEU_DOMINIO.sharepoint.com:/sites/NOME_DO_SITE
```

e copiar o campo `id` da resposta.

## 4. Deploy no Netlify

1. Subir este projeto para um **repositório privado** no GitHub (ver seção 5).
2. No Netlify: **Add new site > Import an existing project > GitHub**,
   selecionar o repositório.
3. Build command: `node build-config.js` (já configurado em `netlify.toml`).
4. Publish directory: `.` (raiz).
5. Em **Site settings > Environment variables**, cadastrar:
   - `VITE_ENTRA_CLIENT_ID`
   - `VITE_ENTRA_TENANT_ID`
   - `VITE_ENTRA_REDIRECT_URI` = `https://mapainteligentesesicabo.netlify.app`
   - `VITE_SHAREPOINT_SITE_ID`
   - `VITE_SHAREPOINT_LIST_ALUNOS` = `Alunos`
   - `VITE_SHAREPOINT_LIST_REGISTROS` = `RegistrosPedagogicos`
6. Fazer o deploy. O `build-config.js` gera `src/config.js` automaticamente
   a cada build — esse arquivo nunca precisa ser editado manualmente.

## 5. Subir para o GitHub

```bash
git init
git add .
git commit -m "versao inicial mapa inteligente do aluno"
git branch -M main
git remote add origin URL_DO_SEU_REPOSITORIO
git push -u origin main
```

Recomenda-se repositório **privado**, já que o código (mesmo sem dados de
aluno) referencia a estrutura interna do tenant.

## 6. O que foi implementado em termos de segurança

- **Login institucional (Entra ID)**: sem senha própria, sem cadastro
  externo; só contas autorizadas do tenant entram (`auth.js`).
- **Zero dado de aluno no código-fonte**: tudo vem do SharePoint via
  Graph, com o token do usuário logado (`sharepoint.js`).
- **Sem localStorage/sessionStorage**: tokens ficam só em memória
  (`cacheLocation: "memoryStorage"` no MSAL), descartados ao fechar a aba.
- **Cabeçalhos HTTP de segurança**: CSP estrita, HSTS, X-Frame-Options,
  Permissions-Policy (`netlify.toml`).
- **Sanitização de erros**: a tela nunca mostra o erro técnico cru do
  Graph; só uma mensagem genérica (detalhe vai pro console local).
- **Minimização de dados (LGPD art. 6º)**: a consulta ao SharePoint já
  filtra `Status eq 'Ativo'`.
- **Rastreabilidade**: cada registro pedagógico grava nome e e-mail do
  professor responsável automaticamente.

## 7. Limitações conhecidas / próximos passos

- O cálculo de risco e os KPIs ainda são simples (regras fixas descritas
  em `dashboard.js`); pode evoluir para considerar histórico, não só a
  média atual.
- Filtros por série/turma/disciplina/período (mencionados na página de
  Evolução) ainda não têm UI — a função `carregarRegistros()` em
  `sharepoint.js` já aceita esses parâmetros, falta ligar a interface.
- `assets/logo-sesi.png` precisa ser adicionada (não incluída aqui por
  ser um arquivo de marca).
- Recomenda-se trocar `Sites.Read.All` por `Sites.Selected` na permissão
  do Graph antes de ir para produção, restringindo o acesso só ao site
  específico do SharePoint usado por este app.
