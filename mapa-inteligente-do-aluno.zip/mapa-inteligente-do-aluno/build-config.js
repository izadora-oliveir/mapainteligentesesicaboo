/**
 * build-config.js
 * Executado pelo Netlify no momento do build (ver netlify.toml).
 * Lê as variáveis de ambiente configuradas no painel do Netlify
 * (Site settings > Environment variables) e gera src/config.js,
 * que é o único lugar onde esses valores aparecem no código publicado.
 *
 * Importante: client ID e tenant ID de um SPA público (MSAL) NÃO são
 * segredos — eles ficam visíveis no JS do navegador de qualquer forma.
 * O que nunca deve existir em lugar nenhum é client secret, senha ou
 * dado de aluno. Por isso usamos variáveis de ambiente apenas para
 * facilitar trocar de tenant/ambiente sem editar código, não por
 * sigilo.
 */
const fs = require("fs");
const path = require("path");

function obrigatorio(nome) {
  const valor = process.env[nome];
  if (!valor) {
    console.warn(`[build-config] Aviso: variável ${nome} não definida.`);
  }
  return valor || "";
}

const config = {
  entraClientId: obrigatorio("VITE_ENTRA_CLIENT_ID"),
  entraTenantId: obrigatorio("VITE_ENTRA_TENANT_ID"),
  entraRedirectUri:
    process.env.VITE_ENTRA_REDIRECT_URI ||
    "https://mapainteligentesesicabo.netlify.app",
  sharepointSiteId: obrigatorio("VITE_SHAREPOINT_SITE_ID"),
  listaAlunos: process.env.VITE_SHAREPOINT_LIST_ALUNOS || "Alunos",
  listaRegistros:
    process.env.VITE_SHAREPOINT_LIST_REGISTROS || "RegistrosPedagogicos",
};

const conteudo = `// Arquivo gerado automaticamente no build (build-config.js).
// Não edite manualmente nem comite este arquivo — ele é gerado a partir
// das variáveis de ambiente do Netlify a cada deploy.
window.APP_CONFIG = ${JSON.stringify(config, null, 2)};
`;

const destino = path.join(__dirname, "src", "config.js");
fs.writeFileSync(destino, conteudo, "utf8");
console.log(`[build-config] src/config.js gerado com sucesso.`);
