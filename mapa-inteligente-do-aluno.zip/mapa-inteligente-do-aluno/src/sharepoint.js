/**
 * sharepoint.js
 * Toda leitura de dados de alunos e registros pedagógicos passa por aqui.
 * Nenhum nome de aluno, nota ou frequência fica hardcoded neste projeto:
 * tudo vem do Microsoft Graph, em tempo real, com o token do usuário logado.
 *
 * Princípios aplicados:
 * - Minimização de dados (LGPD art. 6º): a query já filtra Status = Ativo,
 *   então alunos inativos nunca chegam ao navegador.
 * - Sanitização de erros: detalhes internos da resposta do Graph (que podem
 *   conter info do tenant) nunca são repassados para a tela; só uma
 *   mensagem genérica e um log local de console para depuração.
 */

const cfg = window.APP_CONFIG || {};
const GRAPH_BASE = "https://graph.microsoft.com/v1.0";

async function chamarGraph(url) {
  const token = await window.Auth.obterAccessToken();
  if (!token) throw new Error("Não foi possível obter token de acesso.");

  const resposta = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!resposta.ok) {
    // Loga detalhe técnico só localmente; não expõe ao usuário/tela.
    console.error("Erro Graph API:", resposta.status, await safeText(resposta));
    throw new Error(mensagemAmigavel(resposta.status));
  }

  return resposta.json();
}

async function safeText(resposta) {
  try {
    return await resposta.text();
  } catch {
    return "(sem corpo)";
  }
}

function mensagemAmigavel(status) {
  if (status === 401) return "Sessão expirada. Faça login novamente.";
  if (status === 403) return "Você não tem permissão para acessar estes dados.";
  if (status === 404) return "Lista ou item não encontrado no SharePoint.";
  return "Não foi possível carregar os dados no momento. Tente novamente.";
}

/**
 * Carrega apenas alunos ATIVOS. O filtro "$filter=fields/Status eq 'Ativo'"
 * é aplicado na própria consulta ao Graph, então alunos inativos nunca
 * trafegam até o navegador.
 */
async function carregarAlunos() {
  const url =
    `${GRAPH_BASE}/sites/${cfg.sharepointSiteId}/lists/${cfg.listaAlunos}/items` +
    `?expand=fields&$filter=fields/Status eq 'Ativo'`;

  const data = await chamarGraph(url);

  return data.value.map((item) => ({
    id: item.id,
    nome: item.fields.Nome,
    serie: item.fields.Serie,
    turma: item.fields.Turma,
    matricula: item.fields.Matricula,
  }));
}

/**
 * Carrega registros pedagógicos (notas, frequência, habilidade, etc).
 * Aceita filtros opcionais de turma/disciplina/bimestre para reduzir
 * o volume de dados trafegado (minimização também aplicada aqui).
 */
async function carregarRegistros({ turma, disciplina, bimestre } = {}) {
  let filtro = [];
  if (turma) filtro.push(`fields/Turma eq '${escaparOData(turma)}'`);
  if (disciplina) filtro.push(`fields/Disciplina eq '${escaparOData(disciplina)}'`);
  if (bimestre) filtro.push(`fields/Bimestre eq '${escaparOData(bimestre)}'`);

  let url = `${GRAPH_BASE}/sites/${cfg.sharepointSiteId}/lists/${cfg.listaRegistros}/items?expand=fields`;
  if (filtro.length > 0) url += `&$filter=${filtro.join(" and ")}`;

  const data = await chamarGraph(url);

  return data.value.map((item) => ({
    id: item.id,
    alunoId: item.fields.AlunoIDLookupId || item.fields.AlunoID,
    disciplina: item.fields.Disciplina,
    nota: Number(item.fields.Nota),
    frequencia: Number(item.fields.Frequencia),
    habilidade: item.fields.Habilidade,
    bimestre: item.fields.Bimestre,
    dataRegistro: item.fields.DataRegistro,
    observacao: item.fields.Observacao,
  }));
}

/**
 * Grava um novo registro pedagógico, incluindo automaticamente o nome
 * e e-mail institucional do professor logado, para rastreabilidade.
 */
async function salvarRegistroPedagogico(registro) {
  const usuario = window.Auth.obterUsuarioAtual();
  if (!usuario) throw new Error("Usuário não autenticado.");

  const token = await window.Auth.obterAccessToken();
  const url = `${GRAPH_BASE}/sites/${cfg.sharepointSiteId}/lists/${cfg.listaRegistros}/items`;

  const corpo = {
    fields: {
      ...registro,
      ProfessorNome: usuario.nome,
      ProfessorEmail: usuario.email,
      RegistradoEm: new Date().toISOString(),
    },
  };

  const resposta = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(corpo),
  });

  if (!resposta.ok) {
    console.error("Erro ao salvar registro:", resposta.status, await safeText(resposta));
    throw new Error(mensagemAmigavel(resposta.status));
  }

  return resposta.json();
}

function escaparOData(valor) {
  // Evita quebra do filtro OData por aspas simples no valor.
  return String(valor).replace(/'/g, "''");
}

window.SharePoint = {
  carregarAlunos,
  carregarRegistros,
  salvarRegistroPedagogico,
};
