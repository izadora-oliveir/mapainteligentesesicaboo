/**
 * auth.js
 * Login institucional via Microsoft Entra ID (Azure AD) usando MSAL.js.
 *
 * Regras de segurança aplicadas aqui:
 * - cacheLocation: "memoryStorage" -> nada vai para localStorage/sessionStorage.
 *   O token existe só na memória da aba e desaparece ao fechar/recarregar.
 * - Nenhuma senha é manipulada por este app: o login inteiro acontece no
 *   domínio da Microsoft (login.microsoftonline.com).
 * - O app só pede os escopos mínimos necessários para ler o SharePoint
 *   (Sites.Read.All) e o perfil básico do usuário (User.Read).
 */

const cfg = window.APP_CONFIG || {};

const msalConfig = {
  auth: {
    clientId: cfg.entraClientId,
    authority: `https://login.microsoftonline.com/${cfg.entraTenantId}`,
    redirectUri: cfg.entraRedirectUri,
  },
  cache: {
    // Nunca usar "localStorage" ou "sessionStorage" aqui.
    cacheLocation: "memoryStorage",
    storeAuthStateInCookie: false,
  },
};

const GRAPH_SCOPES = ["User.Read", "Sites.Read.All"];

let msalInstance = null;
let contaAtiva = null;

async function inicializarMsal() {
  if (!cfg.entraClientId || !cfg.entraTenantId) {
    throw new Error(
      "Configuração do Entra ID ausente. Verifique as variáveis de ambiente no Netlify."
    );
  }
  msalInstance = new msal.PublicClientApplication(msalConfig);
  await msalInstance.initialize();

  // Trata o retorno do redirect de login, se for o caso.
  const resposta = await msalInstance.handleRedirectPromise();
  if (resposta && resposta.account) {
    contaAtiva = resposta.account;
  } else {
    const contas = msalInstance.getAllAccounts();
    if (contas.length > 0) {
      contaAtiva = contas[0];
    }
  }
  return contaAtiva;
}

function usuarioEstaAutenticado() {
  return !!contaAtiva;
}

function obterUsuarioAtual() {
  if (!contaAtiva) return null;
  return {
    nome: contaAtiva.name,
    email: contaAtiva.username, // e-mail institucional (UPN)
  };
}

async function login() {
  if (!msalInstance) await inicializarMsal();
  // redirect, não popup: evita problemas de bloqueio de popup e é mais
  // previsível em navegadores institucionais/gerenciados.
  await msalInstance.loginRedirect({ scopes: GRAPH_SCOPES });
}

async function logout() {
  if (!msalInstance || !contaAtiva) return;
  await msalInstance.logoutRedirect({ account: contaAtiva });
}

/**
 * Retorna um access token válido para chamar o Microsoft Graph,
 * sempre obtido por silent renew. O token nunca é gravado em disco,
 * fica apenas em memória (gerenciado internamente pelo MSAL).
 */
async function obterAccessToken() {
  if (!msalInstance || !contaAtiva) {
    throw new Error("Usuário não autenticado.");
  }
  try {
    const resultado = await msalInstance.acquireTokenSilent({
      scopes: GRAPH_SCOPES,
      account: contaAtiva,
    });
    return resultado.accessToken;
  } catch (erro) {
    // Se o token silencioso falhar (ex: expirou de forma que exige
    // interação), manda o usuário para login de novo.
    await msalInstance.acquireTokenRedirect({ scopes: GRAPH_SCOPES });
    return null;
  }
}

window.Auth = {
  inicializarMsal,
  usuarioEstaAutenticado,
  obterUsuarioAtual,
  login,
  logout,
  obterAccessToken,
};
