// Placeholder local. Em produção (Netlify), este arquivo é sobrescrito
// automaticamente pelo build-config.js usando as variáveis de ambiente
// configuradas no painel do Netlify. Para testar localmente, preencha
// os valores abaixo (não comite valores reais de produção aqui).
window.APP_CONFIG = {
  entraClientId: "",
  entraTenantId: "",
  entraRedirectUri: "http://localhost:5500",
  sharepointSiteId: "",
  listaAlunos: "Alunos",
  listaRegistros: "RegistrosPedagogicos"
};
