/**
 * app.js
 * Ponto de entrada. Controla:
 * - gate de autenticação (nada de dados carrega antes do login Microsoft)
 * - navegação entre as páginas (Visão Geral / Evolução / Mapa Pedagógico / Tabela)
 * - orquestração entre SharePoint -> Dashboard
 */

let estado = {
  alunos: [],
  registros: [],
  consolidado: [],
};

async function iniciar() {
  mostrarTelaCarregando("Conectando à sua conta institucional...");

  try {
    const conta = await window.Auth.inicializarMsal();
    if (!conta) {
      mostrarTelaLogin();
      return;
    }
    await entrarNoApp();
  } catch (erro) {
    console.error(erro);
    mostrarErroFatal(
      "Não foi possível iniciar a autenticação institucional. Verifique a configuração do App Registration."
    );
  }
}

function mostrarTelaLogin() {
  document.getElementById("tela-carregando").classList.add("oculto");
  document.getElementById("tela-login").classList.remove("oculto");
  document.getElementById("app-shell").classList.add("oculto");
}

function mostrarTelaCarregando(mensagem) {
  document.getElementById("tela-login").classList.add("oculto");
  document.getElementById("app-shell").classList.add("oculto");
  const tela = document.getElementById("tela-carregando");
  tela.classList.remove("oculto");
  tela.querySelector("p").textContent = mensagem;
}

function mostrarErroFatal(mensagem) {
  const tela = document.getElementById("tela-carregando");
  tela.classList.remove("oculto");
  tela.innerHTML = `
    <div class="erro-fatal">
      <p>${mensagem}</p>
      <button id="btn-tentar-novamente" class="botao-secundario">Tentar novamente</button>
    </div>
  `;
  document
    .getElementById("btn-tentar-novamente")
    .addEventListener("click", () => window.location.reload());
}

async function entrarNoApp() {
  const usuario = window.Auth.obterUsuarioAtual();
  document.getElementById("usuario-nome").textContent = usuario.nome;
  document.getElementById("usuario-email").textContent = usuario.email;

  document.getElementById("tela-login").classList.add("oculto");
  document.getElementById("tela-carregando").classList.add("oculto");
  document.getElementById("app-shell").classList.remove("oculto");

  await carregarDados();
  configurarNavegacao();
  configurarLogout();
}

async function carregarDados() {
  try {
    const [alunos, registros] = await Promise.all([
      window.SharePoint.carregarAlunos(),
      window.SharePoint.carregarRegistros(),
    ]);

    estado.alunos = alunos;
    estado.registros = registros;
    estado.consolidado = window.Dashboard.consolidarPorAluno(alunos, registros);

    renderizarTudo();
  } catch (erro) {
    console.error(erro);
    exibirMensagemDados(erro.message || "Erro ao carregar dados do SharePoint.");
  }
}

function exibirMensagemDados(mensagem) {
  const container = document.getElementById("mensagem-dados");
  if (!container) return;
  container.textContent = mensagem;
  container.classList.remove("oculto");
}

function renderizarTudo() {
  const kpis = window.Dashboard.calcularKPIs(estado.consolidado);
  window.Dashboard.renderizarKPIs(kpis);
  window.Dashboard.renderizarSemaforo(estado.consolidado);
  window.Dashboard.renderizarTabelaAlunos(estado.consolidado);

  window.Dashboard.renderizarGraficoEvolucao(estado.registros);

  const habilidades = window.Dashboard.calcularHabilidades(estado.registros);
  window.Dashboard.renderizarGraficoHabilidades(habilidades);
  window.Dashboard.renderizarTabelaHabilidades(habilidades);
}

function configurarNavegacao() {
  const botoes = document.querySelectorAll(".nav-item");
  const paginas = document.querySelectorAll(".pagina");

  botoes.forEach((botao) => {
    botao.addEventListener("click", () => {
      const destino = botao.dataset.pagina;

      botoes.forEach((b) => b.classList.remove("ativo"));
      botao.classList.add("ativo");

      paginas.forEach((p) => {
        p.classList.toggle("oculto", p.id !== `pagina-${destino}`);
      });
    });
  });
}

function configurarLogout() {
  document.getElementById("btn-logout").addEventListener("click", async () => {
    await window.Auth.logout();
  });
}

document.getElementById("btn-login").addEventListener("click", () => {
  window.Auth.login();
});

iniciar();
