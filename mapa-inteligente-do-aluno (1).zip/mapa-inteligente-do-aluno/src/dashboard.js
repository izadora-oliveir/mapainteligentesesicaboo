/**
 * dashboard.js
 * Cálculos pedagógicos e renderização dos gráficos/indicadores.
 * Não contém nenhum dado de aluno fixo — tudo chega via parâmetro,
 * vindo do SharePoint (ver sharepoint.js).
 */

// Mesma regra de risco descrita no documento de especificação.
function calcularRisco(nota, frequencia) {
  if (nota < 5 || frequencia < 75) return "Alto";
  if (nota <= 7 || frequencia < 85) return "Médio";
  return "Baixo";
}

function corDoSemaforo(nota) {
  if (nota >= 8) return { cor: "verde", label: "Bom desempenho" };
  if (nota >= 5) return { cor: "amarelo", label: "Atenção pedagógica" };
  return { cor: "vermelho", label: "Risco de baixo desempenho" };
}

function media(numeros) {
  if (!numeros.length) return 0;
  return numeros.reduce((a, b) => a + b, 0) / numeros.length;
}

/**
 * Junta alunos + registros pedagógicos em uma visão consolidada por aluno
 * (nota média, frequência média, risco) para alimentar a tabela e os KPIs.
 */
function consolidarPorAluno(alunos, registros) {
  return alunos.map((aluno) => {
    const doAluno = registros.filter((r) => r.alunoId === aluno.id);
    const nota = media(doAluno.map((r) => r.nota));
    const frequencia = media(doAluno.map((r) => r.frequencia));
    return {
      ...aluno,
      nota: Number(nota.toFixed(1)),
      frequencia: Number(frequencia.toFixed(0)),
      risco: calcularRisco(nota, frequencia),
    };
  });
}

function calcularKPIs(consolidado, registros) {
  const total = consolidado.length;
  const notas = consolidado.map((a) => a.nota);
  const frequencias = consolidado.map((a) => a.frequencia);
  const META_DESEMPENHO = 7;
  const avaliados = consolidado.filter((a) => a.nota > 0).length;

  return {
    mediaTurma: total ? media(notas).toFixed(1) : "—",
    quantidadeAlunos: total,
    frequenciaMedia: total ? `${media(frequencias).toFixed(0)}%` : "—",
    taxaDesempenho: total
      ? `${Math.round((notas.filter((n) => n >= META_DESEMPENHO).length / total) * 100)}%`
      : "—",
    alunosEmRisco: consolidado.filter((a) => a.risco === "Alto").length,
    registrosLancados: registros.length,
    alunosAvaliados: avaliados,
    percentualAvaliados: total ? Math.round((avaliados / total) * 100) : 0,
  };
}

/**
 * Agrupa registros por habilidade para a página "Mapa Pedagógico".
 */
function calcularHabilidades(registros) {
  const grupos = {};
  registros.forEach((r) => {
    if (!r.habilidade) return;
    if (!grupos[r.habilidade]) grupos[r.habilidade] = [];
    grupos[r.habilidade].push(r.nota);
  });

  return Object.entries(grupos)
    .map(([habilidade, notas]) => {
      const m = media(notas);
      let status = "Dominada";
      let intervencao = "Manter acompanhamento";
      if (m < 5) {
        status = "Crítica";
        intervencao = "Intervenção imediata";
      } else if (m <= 7) {
        status = "Atenção";
        intervencao = "Reforço dirigido";
      }
      return { habilidade, media: Number(m.toFixed(1)), status, intervencao };
    })
    .sort((a, b) => a.media - b.media);
}

let graficoEvolucao = null;
let graficoHabilidades = null;

function renderizarKPIs(kpis) {
  document.getElementById("kpi-alunos").textContent = kpis.quantidadeAlunos;
  document.getElementById("kpi-alunos-extra").textContent = "Alunos ativos";
  document.getElementById("kpi-registros").textContent = kpis.registrosLancados;
  document.getElementById("kpi-registros-extra").textContent =
    kpis.registrosLancados > 0 ? "Registros pedagógicos" : "Nenhum registro ainda";
  document.getElementById("kpi-media").textContent = kpis.mediaTurma;
  document.getElementById("kpi-risco").textContent = kpis.alunosEmRisco;
  document.getElementById("kpi-risco-extra").textContent =
    kpis.quantidadeAlunos > 0
      ? `${Math.round((kpis.alunosEmRisco / kpis.quantidadeAlunos) * 100)}% do total`
      : "—";

  const topoTotal = document.getElementById("topo-total-alunos");
  if (topoTotal) topoTotal.textContent = kpis.quantidadeAlunos;
}

function renderizarSemaforo(consolidado) {
  const contagem = { verde: 0, amarelo: 0, vermelho: 0 };
  consolidado.forEach((a) => {
    contagem[corDoSemaforo(a.nota).cor]++;
  });
  ["verde", "amarelo", "vermelho"].forEach((cor) => {
    const el = document.getElementById(`semaforo-${cor}`);
    if (el) el.querySelector(".semaforo-valor").textContent = contagem[cor];
  });
}

function renderizarTabelaAlunos(consolidado) {
  const corpo = document.getElementById("tabela-alunos-corpo");
  if (!corpo) return;
  corpo.innerHTML = "";

  if (consolidado.length === 0) {
    corpo.innerHTML = `<tr><td colspan="4" class="tabela-vazia">Nenhum aluno ativo encontrado no SharePoint.</td></tr>`;
    return;
  }

  consolidado.forEach((a) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(a.nome)}</td>
      <td>${a.nota.toFixed(1)}</td>
      <td>${a.frequencia}%</td>
      <td><span class="badge badge-${a.risco.toLowerCase()}">${a.risco}</span></td>
    `;
    corpo.appendChild(tr);
  });
}

function renderizarTabelaHabilidades(habilidades) {
  const corpo = document.getElementById("tabela-habilidades-corpo");
  if (!corpo) return;
  corpo.innerHTML = "";

  if (habilidades.length === 0) {
    corpo.innerHTML = `<tr><td colspan="4" class="tabela-vazia">Sem registros pedagógicos suficientes ainda.</td></tr>`;
    return;
  }

  habilidades.forEach((h) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(h.habilidade)}</td>
      <td>${h.media.toFixed(1)}</td>
      <td><span class="badge badge-status-${h.status.toLowerCase()}">${h.status}</span></td>
      <td>${escapeHtml(h.intervencao)}</td>
    `;
    corpo.appendChild(tr);
  });
}

function renderizarGraficoEvolucao(registros) {
  const canvas = document.getElementById("grafico-evolucao");
  if (!canvas) return;

  const porBimestre = {};
  registros.forEach((r) => {
    if (!r.bimestre) return;
    if (!porBimestre[r.bimestre]) porBimestre[r.bimestre] = [];
    porBimestre[r.bimestre].push(r.nota);
  });

  const labels = Object.keys(porBimestre).sort();
  const dados = labels.map((b) => Number(media(porBimestre[b]).toFixed(1)));

  if (graficoEvolucao) graficoEvolucao.destroy();
  graficoEvolucao = new Chart(canvas, {
    type: "line",
    data: {
      labels,
      datasets: [
        {
          label: "Média geral por bimestre",
          data: dados,
          borderColor: "#00A88E",
          backgroundColor: "rgba(0,168,142,0.12)",
          tension: 0.35,
          fill: true,
          pointRadius: 4,
        },
      ],
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { min: 0, max: 10 } },
    },
  });
}

function renderizarGraficoHabilidades(habilidades) {
  const canvas = document.getElementById("grafico-habilidades");
  if (!canvas) return;

  if (graficoHabilidades) graficoHabilidades.destroy();
  graficoHabilidades = new Chart(canvas, {
    type: "bar",
    data: {
      labels: habilidades.map((h) => h.habilidade),
      datasets: [
        {
          label: "Média por habilidade",
          data: habilidades.map((h) => h.media),
          backgroundColor: habilidades.map((h) =>
            h.media < 5 ? "#D64545" : h.media <= 7 ? "#E0A030" : "#00A88E"
          ),
          borderRadius: 6,
        },
      ],
    },
    options: {
      indexAxis: "y",
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { x: { min: 0, max: 10 } },
    },
  });
}

let graficoDistribuicaoSerie = null;
let graficoMediaDisciplina = null;

function renderizarGraficoDistribuicaoSerie(alunos) {
  const canvas = document.getElementById("grafico-distribuicao-serie");
  if (!canvas) return;

  const porSerie = {};
  alunos.forEach((a) => {
    const serie = a.serie || "Não informado";
    porSerie[serie] = (porSerie[serie] || 0) + 1;
  });

  const labels = Object.keys(porSerie).sort();
  const cores = ["#2BBBA4", "#8B6FD6", "#5FBF8F", "#E0A030", "#D6555A", "#3F8FD6"];

  if (graficoDistribuicaoSerie) graficoDistribuicaoSerie.destroy();
  graficoDistribuicaoSerie = new Chart(canvas, {
    type: "bar",
    data: {
      labels,
      datasets: [
        {
          label: "Alunos",
          data: labels.map((s) => porSerie[s]),
          backgroundColor: labels.map((_, i) => cores[i % cores.length]),
          borderRadius: 6,
        },
      ],
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } },
    },
  });
}

function renderizarGraficoMediaDisciplina(registros) {
  const canvas = document.getElementById("grafico-media-disciplina");
  if (!canvas) return;

  const porDisciplina = {};
  registros.forEach((r) => {
    if (!r.disciplina) return;
    if (!porDisciplina[r.disciplina]) porDisciplina[r.disciplina] = [];
    porDisciplina[r.disciplina].push(r.nota);
  });

  const labels = Object.keys(porDisciplina).sort();
  const dados = labels.map((d) => Number(media(porDisciplina[d]).toFixed(1)));

  if (graficoMediaDisciplina) graficoMediaDisciplina.destroy();
  graficoMediaDisciplina = new Chart(canvas, {
    type: "bar",
    data: {
      labels,
      datasets: [
        {
          label: "Média",
          data: dados,
          backgroundColor: "#2BBBA4",
          borderRadius: 6,
        },
      ],
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { min: 0, max: 10 } },
    },
  });
}

/**
 * Gera um CSV simples a partir da tabela consolidada de alunos e
 * dispara o download no navegador. Não depende de nenhuma lib externa.
 */
function exportarAlunosCSV(consolidado) {
  const cabecalho = ["Nome", "Série", "Turma", "Nota", "Frequência", "Risco"];
  const linhas = consolidado.map((a) =>
    [a.nome, a.serie, a.turma, a.nota.toFixed(1), `${a.frequencia}%`, a.risco]
      .map((v) => `"${String(v ?? "").replaceAll('"', '""')}"`)
      .join(",")
  );
  const csv = [cabecalho.join(","), ...linhas].join("\n");

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `mapa-inteligente-alunos-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function escapeHtml(str) {
  if (str == null) return "";
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

window.Dashboard = {
  calcularRisco,
  corDoSemaforo,
  consolidarPorAluno,
  calcularKPIs,
  calcularHabilidades,
  renderizarKPIs,
  renderizarSemaforo,
  renderizarTabelaAlunos,
  renderizarTabelaHabilidades,
  renderizarGraficoEvolucao,
  renderizarGraficoHabilidades,
  renderizarGraficoDistribuicaoSerie,
  renderizarGraficoMediaDisciplina,
  exportarAlunosCSV,
};
